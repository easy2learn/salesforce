package com.saleforce.tool.api.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;

import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;

import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.saleforce.tool.api.response.AccountResponse;

/*Avinash Kumar */
@Service
public class ApiService {

	private final static Logger logger = LoggerFactory.getLogger(ApiService.class);
	static final String USERNAME = "kumaravinash573@gmail.com";
	static final String PASSWORD = "test12348EEahbGjUCkjoV1DrsRQHlGx";
	static final String LOGINURL = "https://login.salesforce.com";
	static final String GRANTSERVICE = "/services/oauth2/token?grant_type=password";
	static final String CLIENTID = "3MVG9fe4g9fhX0E5CXyDoUcjyNIeW_7_wJ61QlMHlwO_dqXVUNLtmLanoE3xOcDBl1sPv4_9qlVxn3uMc21ye";
	static final String CLIENTSECRET = "B59D5158C81DB5E7709170D787C657D7C23621EE2AD593307C73066498B90561";
	private static String REST_ENDPOINT = "/services/data";
	private static String API_VERSION = "/v50.0";
	private static String baseUri;
	private static Header oauthHeader;
	private static Header prettyPrintHeader = new BasicHeader("X-PrettyPrint", "1");

	private static String name;
	private static String type;
	ObjectMapper mp = new ObjectMapper();
	// API call

	public String doOperation(int value) {

		// Assemble the login request URL
		String loginURL = LOGINURL + GRANTSERVICE + "&client_id=" + CLIENTID + "&client_secret=" + CLIENTSECRET
				+ "&username=" + USERNAME + "&password=" + PASSWORD;

		logger.info("login URL:https://login.salesforce.com/services/oauth2/token: With :" + loginURL);

		// Login requests must be POSTs
		HttpPost httpPost = new HttpPost(loginURL);
		Header token = getToken(httpPost);

		String resp = null;

		switch (value) {
		case 1:
			resp = listAvailableToolAPI();
			break;
		case 2:
			//
			resp = objectDescribe();
			break;
		case 3:
			resp = getObject();
			break;
		default:
			resp = "Value should be between 1 to 3";
		}

		// release connection
		httpPost.releaseConnection();

		return resp;
	}

	private String getObject() {
		System.out.println("\n_______________ Object Tool API _______________");
		String response_string = null;
		try {

			// Set up the HTTP objects needed to make the request.
			HttpClient httpClient = HttpClientBuilder.create().build();

			String uri = baseUri + "/tooling/sobjects/AccountSettings";
			System.out.println("Query URL: " + uri);
			HttpGet httpGet = new HttpGet(uri);
			System.out.println("oauthHeader2: " + oauthHeader);
			httpGet.addHeader(oauthHeader);
			httpGet.addHeader(prettyPrintHeader);

			// Make the request.
			HttpResponse response = httpClient.execute(httpGet);

			// Process the result
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				response_string = EntityUtils.toString(response.getEntity());

				System.out.println("print payload :" + response_string);
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return response_string;

	}

	private String objectDescribe() {

		System.out.println("\n_______________ Object Describe Tool API _______________");
		String response_string = null;
		try {

			// Set up the HTTP objects needed to make the request.
			HttpClient httpClient = HttpClientBuilder.create().build();

			String uri = baseUri + "/tooling/sobjects/AccountInsightsSettings/describe";
			System.out.println("Query URL: " + uri);
			HttpGet httpGet = new HttpGet(uri);
			System.out.println("oauthHeader2: " + oauthHeader);
			httpGet.addHeader(oauthHeader);
			httpGet.addHeader(prettyPrintHeader);

			// Make the request.
			HttpResponse response = httpClient.execute(httpGet);

			// Process the result
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				response_string = EntityUtils.toString(response.getEntity());

				System.out.println("print payload :" + response_string);
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return response_string;
	}

	// getting token
	private Header getToken(HttpPost httpPost) {
		HttpClient httpclient = HttpClientBuilder.create().build();
		HttpResponse response = null;

		try {
			// Execute the login POST request
			response = httpclient.execute(httpPost);
		} catch (ClientProtocolException cpException) {
			cpException.printStackTrace();
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		// verify response is HTTP OK
		final int statusCode = response.getStatusLine().getStatusCode();
		if (statusCode != HttpStatus.SC_OK) {
			System.out.println("Error authenticating to Force.com: " + statusCode);

		}

		String getResult = null;
		try {
			getResult = EntityUtils.toString(response.getEntity());
		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		JSONObject jsonObject = null;
		String loginAccessToken = null;
		String loginInstanceUrl = null;

		try {
			jsonObject = (JSONObject) new JSONTokener(getResult).nextValue();
			loginAccessToken = jsonObject.getString("access_token");
			loginInstanceUrl = jsonObject.getString("instance_url");
		} catch (JSONException jsonException) {
			jsonException.printStackTrace();
		}

		baseUri = loginInstanceUrl + REST_ENDPOINT + API_VERSION;
		oauthHeader = new BasicHeader("Authorization", "OAuth " + loginAccessToken);
		logger.info("oauthHeader1: " + oauthHeader);
		logger.info("\n" + response.getStatusLine());
		logger.info("Successful login");
		logger.info("instance URL: " + loginInstanceUrl);
		logger.info("access token/session ID: " + loginAccessToken);
		logger.info("baseUri: " + baseUri);

		return oauthHeader;
	}

	// getting list of API
	public static String listAvailableToolAPI() {

		System.out.println("\n_______________ List Available Tool API _______________");
		String response_string = null;
		try {

			// Set up the HTTP objects needed to make the request.
			HttpClient httpClient = HttpClientBuilder.create().build();

			String uri = baseUri + "/tooling/sobjects";
			System.out.println("Query URL: " + uri);
			HttpGet httpGet = new HttpGet(uri);
			System.out.println("oauthHeader2: " + oauthHeader);
			httpGet.addHeader(oauthHeader);
			httpGet.addHeader(prettyPrintHeader);

			// Make the request.
			HttpResponse response = httpClient.execute(httpGet);

			// Process the result
			int statusCode = response.getStatusLine().getStatusCode();
			if (statusCode == 200) {
				response_string = EntityUtils.toString(response.getEntity());

				System.out.println("print payload :" + response_string);
			}
		} catch (Exception e) {
			logger.info(e.getMessage());
		}
		return response_string;
	}

	// Query Leads
	public static String queryAccount() {
		System.out.println("\n_______________ Account QUERY _______________");
		String resp = null;
		
		
		List<AccountResponse> accountDetails = new ArrayList<>();
		try {

			// Set up the HTTP objects needed to make the request.
			HttpClient httpClient = HttpClientBuilder.create().build();

			String uri = baseUri + "/query/?q=SELECT+Name,Type+FROM+Account";
			System.out.println("Query URL: " + uri);
			HttpGet httpGet = new HttpGet(uri);
			System.out.println("oauthHeader2: " + oauthHeader);
			httpGet.addHeader(oauthHeader);
			httpGet.addHeader(prettyPrintHeader);

			// Make the request.
			HttpResponse response = httpClient.execute(httpGet);

			// Process the result
			int statusCode = response.getStatusLine().getStatusCode();

			
			if (statusCode == 200) {
				String response_string = EntityUtils.toString(response.getEntity());
				try {
					JSONObject json = new JSONObject(response_string);
					System.out.println("JSON result of Query:\n" + json.toString(1));
					JSONArray j = json.getJSONArray("records");
					AccountResponse acount = new AccountResponse();
					for (int i = 0; i < j.length(); i++) {
						type = json.getJSONArray("records").getJSONObject(i).getString("Type");
						name = json.getJSONArray("records").getJSONObject(i).getString("Name");
						acount.setName(name);
						acount.setType(type);
						accountDetails.add(acount);

						System.out.println("Account record is: " + accountDetails.toString());
					}
					//resp = mp.writeValueAsString(accountDetails);
					
					System.out.println("Account record is: " + resp);
				} catch (JSONException je) {
					je.printStackTrace();
				}
			} else {
				System.out.println("Query was unsuccessful. Status code returned is " + statusCode);
				System.out.println("An error has occured. Http status: " + response.getStatusLine().getStatusCode());
				System.out.println(getBody(response.getEntity().getContent()));
				System.exit(-1);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (NullPointerException npe) {
			npe.printStackTrace();
		}

		return accountDetails.toString();
	}

	private static class HttpPatch extends HttpPost {
		public HttpPatch(String uri) {
			super(uri);
		}

		public String getMethod() {
			return "PATCH";
		}
	}

	private static String getBody(InputStream inputStream) {
		String result = "";
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
			String inputLine;
			while ((inputLine = in.readLine()) != null) {
				result += inputLine;
				result += "\n";
			}
			in.close();
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
		return result;
	}

	public List<AccountResponse> getAccountDetails() {
		logger.info("\n_______________ Account QUERY _______________");

		// Assemble the login request URL
		String loginURL = LOGINURL + GRANTSERVICE + "&client_id=" + CLIENTID + "&client_secret=" + CLIENTSECRET
				+ "&username=" + USERNAME + "&password=" + PASSWORD;

		logger.info("login URL:https://login.salesforce.com/services/oauth2/token: With :" + loginURL);

		// Login requests must be POSTs
		HttpPost httpPost = new HttpPost(loginURL);
		Header token = getToken(httpPost);

		
		// release connection
		httpPost.releaseConnection();
		String resp = null;
		
		
		List<AccountResponse> accountDetails = new ArrayList<>();
		try {

			// Set up the HTTP objects needed to make the request.
			HttpClient httpClient = HttpClientBuilder.create().build();

			String uri = baseUri + "/query/?q=SELECT+Name,Type+FROM+Account";
			System.out.println("Query URL: " + uri);
			HttpGet httpGet = new HttpGet(uri);
			System.out.println("oauthHeader2: " + oauthHeader);
			httpGet.addHeader(oauthHeader);
			httpGet.addHeader(prettyPrintHeader);

			// Make the request.
			HttpResponse response = httpClient.execute(httpGet);

			// Process the result
			int statusCode = response.getStatusLine().getStatusCode();

			
			if (statusCode == 200) {
				String response_string = EntityUtils.toString(response.getEntity());
				try {
					JSONObject json = new JSONObject(response_string);
					System.out.println("JSON result of Query:\n" + json.toString(1));
					JSONArray j = json.getJSONArray("records");
					AccountResponse acount = new AccountResponse();
					for (int i = 0; i < j.length(); i++) {
						type = json.getJSONArray("records").getJSONObject(i).getString("Type");
						name = json.getJSONArray("records").getJSONObject(i).getString("Name");
						acount.setName(name);
						acount.setType(type);
						accountDetails.add(acount);

						System.out.println("Account record is: " + accountDetails.toString());
					}
					//resp = mp.writeValueAsString(accountDetails);
					
					System.out.println("Account record is: " + resp);
				} catch (JSONException je) {
					je.printStackTrace();
				}
			} else {
				System.out.println("Query was unsuccessful. Status code returned is " + statusCode);
				System.out.println("An error has occured. Http status: " + response.getStatusLine().getStatusCode());
				System.out.println(getBody(response.getEntity().getContent()));
				System.exit(-1);
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} catch (NullPointerException npe) {
			npe.printStackTrace();
		}

		return accountDetails;
	}

}
