package com.saleforce.tool.api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.saleforce.tool.api.response.AccountResponse;
import com.saleforce.tool.api.service.ApiService;

/*Avinash Kumar */
@RestController
public class ApiController {
	@Autowired
	ApiService apiService;
	private final Logger logger = LoggerFactory.getLogger(ApiController.class);

	// Lists the available Tooling API objects and their metadata
	@GetMapping(path = "/data", produces = "application/json")
	public ResponseEntity<String> getListAvailableToolAPI(@RequestParam int value) {

		String resp = apiService.doOperation(value);
		ResponseEntity<String> response = new ResponseEntity<>(resp, HttpStatus.OK);
		logger.info("executed successfuly");
		return response;
	}

	

	// name and type from Account
	@GetMapping(path = "/account", produces = "application/json")
	public ResponseEntity<List<AccountResponse>> getAccountDetails() {

		List<AccountResponse> resp = apiService.getAccountDetails();
		return new ResponseEntity<List<AccountResponse>>(resp, HttpStatus.OK);

	}

}
